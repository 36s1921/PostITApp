export const UserData=[
    {
        name:"Ali",
        email:"ali@gmail.com",
        password:"12345",
    },
    {
        name:"Ahmad",
        email:"ahmad@gmail.com",
        password:"12346",
    },
    {
        name:"Zaid",
        email:"ziad@gmail.com",
        password:"12347",
    },
];