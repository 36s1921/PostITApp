const Footer = () => {
  return (
    <footer className="footer">
      <div>©2023.PostIT. All Rights Reserved.</div>
    </footer>
  );
};

export default Footer;
