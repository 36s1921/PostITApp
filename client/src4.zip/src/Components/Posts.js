

const Posts = () => {
  return (
    <div className="postsContainer">
      <h1>Display Posts</h1>
    </div> /* End of posts */
  );
};

export default Posts;
