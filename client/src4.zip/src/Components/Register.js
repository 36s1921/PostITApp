import {useDispatch, useSelector} from "react-redux";
import { useState,state,onSubmit } from "react";
import {registerUser,deleteUser,updateUser} from "../Features/User";
import  {Button,Col,Label,Container,Row,FormGroup,Input,Form} from "reactstrap";
import { Link } from "react-router-dom";
import { userSchemaValidation } from "../Validations/UserValidation";
import * as yup from "yup";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { addUser } from "../Features/User";
const Register = () => {
  const userList= useSelector((state)= state.users.value);
  const [name,setname]=useState("");
  const [email,setemail]=useState("");
  const [password,setpassword]=useState("");
  const [confirmPassword,setconfirmPassword]=useState("");
  const dispatch=useDispatch();
  const {
    setValue,
    register,
    handleSubmit:submitForm, 
    trigger,
    formState:{errors},
  } = useForm({
    resolver: yupResolver(userSchemaValidation), 
  });
    const handleSubmit = (data) => {
      console.log("Form Data", data); 
      const userData ={
        name:data.name,
        email:data.email,
        password:data.password,
      };
      dispatch(registerUser(userData));
    };
    const handleDelete=(email)=>{
      dispatch(deleteUser(email));
    };
    const handleUpdate=(email)=>{
      const userData ={
        name:name,
        email:email,
        password:password,
        confirmPassword:confirmPassword,
      };
      dispatch(updateUser(userData))
    }
  return (
    
    <Container fluid>
    <Form onSubmit={handleSubmit(onSubmit)}>
  <Row className="formrow">
    <Col className="columndiv1" lg="6">
  <FormGroup>
        <Label for="name">
          name
        </Label>
        <Input
          className="form-control"
          id="name"
          
          placeholder="Enter your name"
          type="text"
          {
            ...register("name")
          }
          onChange={(e)=>{setValue("name",e.target.value);
            trigger("name");}
          }
        />
        <p className="errors">{errors.name?.massege}</p>
      </FormGroup>
      </Col>
      <Row className="formrow">
    <Col className="columndiv1" lg="6">
      <FormGroup>
        <Label for="exampleEmail">
          Email
        </Label>
        <Input
        className="form-control"
          id="Email"
          
          placeholder="enter your email"
          type="text"
          {
            ...register("Email")
          }
          onChange={(e)=>{setValue("Email",e.target.value);
            trigger("Email");}
          }
        />
        <p className="Email">{errors.name?.massege}</p>
      </FormGroup>
      </Col>
      </Row>
      <Row className="formrow">
    <Col className="columndiv1" lg="6">
      <FormGroup>
        <Label for="examplePassword">
          Password
        </Label>
        <Input
        className="form-control"
          id="Password"
          
          placeholder="password requaired"
          type="Password"
          {
            ...register("password")
          }
          onChange={(e)=>{setValue("password",e.target.value);
            trigger("password");}
          }
        />
        <p className="password">{errors.name?.massege}</p>
      </FormGroup>
      </Col>
      </Row>
      <Row className="formrow">
    <Col className="columndiv1" lg="6">
      <FormGroup>
        <Label for="confirmPassword">
          ConfirmPassword
        </Label>
        <Input
        className="form-control"
          id="confirmPassword"
          
          placeholder="confirm your Password"
          type="Password"
          {
            ...register("confirmPassword")
          }
          onChange={(e)=>{setValue("confirmPassword",e.target.value);
            trigger("confirmPassword");}
          }
        />
        <p className="confirmPassword">{errors.name?.massege}</p>
      </FormGroup>
      </Col>
      </Row>
      <FormGroup>
      <Button>
          Register
        </Button>
      </FormGroup>
  </Row>
  <Row>
    <div>
      <table>
        {userList.map((user)=>(
          <tr key={user.email}>
            <td>
              {user.name}
            </td>
            <td>
              {user.email}
            </td>
            <td>
              {user.password}
            </td>
            <td>
            <Button onClick={()=> handleDelete(user.email)} type="button">
              Delete user
            </Button>
            </td>
            <td>
            <Button onClick={()=> handleUpdate(user.email)} type="button">
              Update user
            </Button>
            </td>
          </tr>
        ))}
        
      </table>
    </div>
  </Row>
  </Form>
  </Container>
  );
};
export default Register;
