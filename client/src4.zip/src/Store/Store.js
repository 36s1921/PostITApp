import { configureStore } from '@reduxjs/toolkit';
import { usesReducer } from './Features/User';
export const store = configureStore({
 reducer: {
    users:usesReducer,
 },
});
