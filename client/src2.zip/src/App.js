import "./App.css";
import Login from "./Components/Login";
import Header from "./Components/Header";
import Profile from "./Components/Profile";
import Footer from "./Components/Footer";
import "bootstrap/dist/css/bootstrap.min.css";
import {Container, Row, Col} from "reactstrap";
import {BrowserRouter as Router, Routes, Route} from "react-router-dom";
import Home from "./Components/Home";
import Register from "./Components/Register";
const App = () => {
  return (
    <>
    <Container>
      <Router>
      <Row>
        <Header/>
      </Row>
      <Row className="main">
        <Routes>
          <Route path="/" element={<Home/>}></Route>
          <Route path="Login" element={<Login/>}></Route>
          <Route path="Profile" element={<Profile/>}></Route>
          <Route path="Register" element={<Register/>}></Route>
        </Routes>
      </Row>
      <Row>
        <Footer/>
      </Row>
      </Router>
    </Container>
    </>
  );
};
export default App;
