import { createSlice } from "@reduxjs/toolkit";
import {UserData} from "../ExampleData";
const initialState={value: UserData};
export const userSlice= createSlice({
    name:"users",
    initialState,
    reducers:{
        registerUser:(state, action)=>{
            state.value.push(action.payload);
        },
    },
});
export default userSlice.reducer;