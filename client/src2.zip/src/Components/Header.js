import {Navbar,Nav,NavItem,NavLink}from "reactstrap";
import logo from "../Images/logo-t.png";
import {Link} from "react-router-dom";
const Header = () => {

  return (
    <>
      <Navbar className="Header">
        <Nav>
        <NavItem>
       
        <Link to="/"><img src={logo}/></Link>
          </NavItem>
          <NavItem>
            <Link to="/">Home</Link>
          </NavItem>
          <NavItem>
            <Link to="/Login">Login</Link>
          </NavItem>
          <NavItem>
          <Link to="/Profile">Profile</Link>
          </NavItem>
          <NavItem>
          <Link to="/Logout">Logout</Link>
          </NavItem>
        </Nav>
      </Navbar>
    </>
  );
};
export default Header;
