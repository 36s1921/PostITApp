import { createSlice } from "@reduxjs/toolkit";
import {UserData} from '../Validations/ExampleData';
import { act } from "react";
const initialState={value: UserData};
export const user= createSlice({
    name:"users",
    initialState,
    reducers:{
        registerUser:(state, action)=>{
            state.value.push(action.payload);
        },
        deleteUser:(state,action)=>{
            state.value = state.value.filter((user)=>user.email!== action.payload)
        },
        updateUser:(state,action)=>{
            state.value.map((user)=>{
                if(user.email===action.payload.email){
                    user.name= action.payload.name;
                    user.password= action.payload.password;
                }
            })
        }
    },
});
export default user.reducer;
export const {registerUser,deleteUser,updateUser}=user.action;
export const usesReducer= user.reducer;